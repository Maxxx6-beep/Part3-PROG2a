public class Task {
    private int id;
    private String title;
    private String description;
    private String reminder;
    private boolean completed;
    public Task(int id, String description, String reminder, String title, boolean completed){

        this.id = id;
        this.title = title;
        this. descreption = descreption;
        this. reminder = reminder;
        this. completed = completed;
    } 
    public int getid() {

        returm id;
    }
    public String gettitle() {
        return title;
    }
    public String getdescription() {
        return descreption;
    }
    public String getreminder() {
        return reminder;
    }
    if (userMessage.contains("Add task")
    userMessage.contains("create task")
|| userMessage.contains("new task")) {
    return"task is detected and please  enter task details";

}
if (userMessage.contains("remind me")
    userMessage.contains("set reminder")
|| userMessage.contains("remember to")) {
    return"reminder is detected and please  enter a date";
}
if (userMessage.contains("pishing")
    userMessage.contains("fake email.")
|| userMessage.contains("scam email")) {
    return"be carefull of suspicius emails and links";
}
if (userMessage.contains("password")
    userMessage.contains("credentials")
|| userMessage.contains("login")) {
    return"remember to use a strong password";
}