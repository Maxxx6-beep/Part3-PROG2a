import java.uti.Random;
public clas CyberSecurityChatbot {

String userName = "";
String lastTopic = "";
Random random = new Random();
public String getResponse (String userMessage) {


    userMessage = userMessage.toLowerCase();
    if(userName.startsWith("my name is")) {

        userName = userMessage.replace("my name is", "").trim();
        return "pleasure to meet you," + userName + "!";
    }
    if(userMessage.contains("what is my name")){

        if(!userName.isEmpty()) {
            return "your name is" + userName + ":";

        } else {
            return " i dont know your name yet";
        }
    }
}
if  (userName.contains("sad")) {
    return " i am very sore that you are feeling sad";
}
if (userName.contains("happy")) {
    return "that is very wonderfull to hear";
}
if (userName.contains("Angry")){
    return " i do understand that you are very upset";
}
}
if (userMessage.contains("password")) {

    lastTopic = "password";
    String [] response = {

        "please use strong password that contains symbols",
        "never show or share your password with anyone",
        "use different passwords for different acconts"
    };
}
if (userMessage.contains("scam")) {

    lastTopic = "scam";
    String [] response = {
        "never send money to the person you do not know".
        "Scamers usually create fake accounts"

    };
    return response[random.nextInt(response.length)];
}
if (userMessage.contains("pishing")) {

    lastTopic = "pishing";
    String [] response = {

        "avoid clicking to links that you are sure of",
        "do not  private information"
};
return response[random.nextInt(response.length)];
}
if (userMessage.contains("hello")
|| userMessage.contains("hi")) {

if(!userName.isEmpty()) {
    return "hello again," + userName + "!";
} else {
    return "hi, how can i assist you today";
}
}
if (userName.contains("bye")
|| userMessage.contains("exit")) {
return "stay safe online,goodbye";

}
return "please ask me about CyberSecurity topics like password and pishing"
